from django.shortcuts import render

# Create your views here.
def Irecord(request):
    return render(request, 'Pimages/Irecord.html')

def addimages(request):
    return render(request,'Pimages/addimages.html')
