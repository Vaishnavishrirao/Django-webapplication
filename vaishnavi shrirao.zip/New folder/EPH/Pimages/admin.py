from django.contrib import admin
from Pimages.models import *
# Register your models here.
admin.site.register(P_Images)