from django.apps import AppConfig


class MyaccConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Pimages'
