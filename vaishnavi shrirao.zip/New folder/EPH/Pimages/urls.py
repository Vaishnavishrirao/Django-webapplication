from django.urls import path
from Pimages.views import *
urlpatterns=[
    path('Irecord/',Irecord,name='Irecord'),
    path('addimages/',addimages,name='addimages')
]