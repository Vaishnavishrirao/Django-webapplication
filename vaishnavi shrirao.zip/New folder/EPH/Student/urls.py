from django.urls import path
from Student.views import *

urlpatterns = [
    path('',home,name='home') ,
    path('about/',about,name='about') ,
    path('electronics_projects/',electronics_projects,name='electronics_projects') ,
    path('mechanical_projects/',mechanical_projects,name='mechanical_projects') ,
    path('software_projects/',software_projects,name='software_projects') ,
    path('embedded_projects/',embedded_projects,name='embedded_projects') ,
    path('iot_projects/',iot_projects,name='iot_projects') ,
    path('matlab_projects/',matlab_projects,name='matlab_projects') ,
    path('registration/',registration,name='registration') ,
    path('Pimages/',Pimages,name='Pimages'),

]