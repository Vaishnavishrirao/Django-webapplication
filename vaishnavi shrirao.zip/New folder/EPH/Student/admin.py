from django.contrib import admin
from Student.models import *
# Register your models here.
admin.site.register(S_D)