from django.shortcuts import render,redirect
from Pimages.models import P_Images
from Student.models import *
# Create your views here.
def home(request):
    return render(request, 'Student/home.html')

def about(request):
    return render(request, 'Student/about.html')

def electronics_projects(request):
    return render(request, 'Student/electronics_projects.html')

def mechanical_projects(request):
    return render(request, 'Student/mechanical_projects.html')

def software_projects(request):
    return render(request, 'Student/software_projects.html')

def embedded_projects(request):
    return render(request, 'Student/embedded_projects.html')

def iot_projects(request):
    return render(request, 'Student/iot_projects.html')

def matlab_projects(request):
    return render(request, 'Student/matlab_projects.html')

def registration(request):
    if request.method == 'POST':
        n=request.POST.get('n')
        d=request.POST.get('d')
        mb=request.POST.get('mb')      
        m=request.POST.get('m')
        data=S_D(name=n,degree=d,mobile=mb,email=m)
        data.save()
        return redirect('home')
    return render(request, 'Student/registration.html')

def Pimages(request):
    data=P_Images.objects.all()
    context={
        'data':data
    }
    return render(request,'Student/Pimages.html',context)
