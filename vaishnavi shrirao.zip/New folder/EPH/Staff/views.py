from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib import auth
from Student.models import S_D
from django.contrib.auth.decorators import login_required
# Create your views here.
def signup(request):
    if request.method=="POST":
        fn=request.POST.get('fn')
        ln=request.POST.get('ln')
        un=request.POST.get('un')
        e=request.POST.get('e')
        p1=request.POST.get('p1')
        p2=request.POST.get('p2')
        if p1!=p2:
            if  User.objects.filter(username=un).exists():
               messages.error(request, 'username already exist')
               return redirect('signup')

            else:
                User.objects.create_user(first_name=fn,last_name=ln,username=un,email=e,password=p1)
                return redirect('login')

        else:
            messages.error(request,"password not matched")
            return redirect('signup')

    return render(request, 'Staff/signup.html')

def login(request):
    if request.method == 'POST':
        un=request.POST.get('un')
        p1=request.POST.get('p1')
        u= auth.authenticate(username=un,password=p1)
        if u is not None:
            auth.login(request, u)
            return redirect('dashboard')
        else:
            messages.error(request,'invalid')
    return render(request, 'Staff/login.html')

@login_required(login_url='login')
def dashboard(request):
    student=S_D.objects.all()
    context={'student':student}
    return render(request, 'Staff/dashboard.html',context)

def logout(request):
    auth.logout(request)
    return redirect('home')

def update(request,id):
    student=S_D.objects.get(pk=id)
    context={'student':student}
    if request.method == 'POST':
        n=request.POST.get('n')
        d=request.POST.get('d')
        mb=request.POST.get('mb')      
        m=request.POST.get('m')
        student.name=n
        student.degree=d
        student.mobile=mb
        student.email=m
        student.save()
        return redirect('dashboard')
    return render(request, 'Staff/update.html',context)

def delete(request,id):
    s=S_D.objects.get(pk=id)
    s.delete()
    return redirect('dashboard')
