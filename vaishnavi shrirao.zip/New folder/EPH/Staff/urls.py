from django.urls import path
from Staff.views import *

urlpatterns = [
    path('signup/',signup,name='signup'),
    path('login/',login,name='login'),
    path('logout/',logout,name='logout'),
    path('dashboard/',dashboard,name='dashboard'),
    path('dashboard/update/<id>',update,name='update'),
    path('dashboard/delete/<id>',delete,name='delete'),
]